package addressbook;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.function.Predicate;
import java.util.Scanner;

public class addressBookController {

    // Table
    @FXML private TableView<Person> addressBookTable;
    @FXML private TableColumn<Person, String> firstColumn;
    @FXML private TableColumn<Person, String> lastColumn;
    @FXML private TableColumn<Person, String> addressColumn;
    @FXML private TableColumn<Person, String> cityColumn;
    @FXML private TableColumn<Person, String> stateColumn;
    @FXML private TableColumn<Person, String> zipColumn;

    // Text Fields
    @FXML private TextField firstTextField;
    @FXML private TextField lastTextField;
    @FXML private TextField addressTextField;
    @FXML private TextField cityTextField;
    @FXML private TextField stateTextField;
    @FXML private TextField zipTextField;

    // Anchor Pane
    @FXML private AnchorPane addressBookAnchorPane;

    // Create a variable for the csv file
    private final File csvFile = new File("addressBook.csv");
    // Store data using observable list
    private final ObservableList<Person> addressList = FXCollections.observableArrayList();

    public void initialize() {
        // Assign the values of Person to columns in the table
        firstColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));
        lastColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("address"));
        cityColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("city"));
        stateColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("state"));
        zipColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("zip"));

        // Add a listener to the address book so that when the user selects a row, the text fields will populate with that row
        addressBookTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                firstTextField.setText(newSelection.getFirstName());
                lastTextField.setText(newSelection.getLastName());
                addressTextField.setText(newSelection.getAddress());
                cityTextField.setText(newSelection.getCity());
                stateTextField.setText(newSelection.getState());
                zipTextField.setText(newSelection.getZip());
            }
        });

        if (csvFile.exists()) {
            loadFromCSV();
            addressBookTable.setItems(addressList);
        }
    }

    // handles Clear Button's ActionEvents
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        // Clear all text fields
        firstTextField.clear();
        lastTextField.clear();
        addressTextField.clear();
        cityTextField.clear();
        stateTextField.clear();
        zipTextField.clear();

        // Clear all selections
        addressBookTable.getSelectionModel().clearSelection();

        // Display the whole book (reset the Find button results)
        addressBookTable.setItems(addressList);
    }

    // handles Update Button's ActionEvents
    @FXML
    private void onUpdateButtonClick(ActionEvent event) {

        // Retrieve the values in each text field
        String firstName = firstTextField.getText();
        String lastName = lastTextField.getText();
        String address = addressTextField.getText();
        String city = cityTextField.getText();
        String state = stateTextField.getText();
        String zip = zipTextField.getText();

        // Validate the input
        try {
            // Test to see if the first and last name, state, and zip code are valid.
            // An exception will be thrown if invalid.
            isValidName(firstName);
            isValidName(lastName);
            isValidState(state);
            isValidZip(zip);

            // If the input is valid, the program will proceed to add/update the table

            // If no record is selected, add a new record
            if (addressBookTable.getSelectionModel().isEmpty()) {
                Person newPerson = new Person(firstName, lastName, address, city, state, zip);
                System.out.println("Adding to table: " + newPerson.toString());

                addressList.add(newPerson);
                addressBookTable.setItems(addressList);
                saveToCSV();
            }
            else { // Otherwise update the selected record
                Person selectedPerson = addressBookTable.getSelectionModel().getSelectedItem();
                selectedPerson.setFirstName(firstName);
                selectedPerson.setLastName(lastName);
                selectedPerson.setAddress(address);
                selectedPerson.setCity(city);
                selectedPerson.setState(state);
                selectedPerson.setZip(zip);

                // Update the table with the changes
                addressBookTable.refresh();
                // Update the CSV
                saveToCSV();
            }
        }
        catch(IllegalArgumentException e) {
            // Display warning message
            System.out.println(e.getMessage());
            showWarning(e.getMessage());
        }
    }

    @FXML
    private void onDeleteButtonClick (ActionEvent event) {
        // Remove the selected record from the data store
        Person selectedPerson = addressBookTable.getSelectionModel().getSelectedItem();
        addressList.remove(selectedPerson);
        addressBookTable.refresh();
        saveToCSV();
    }

    @FXML
    private void onFindButtonClick (ActionEvent event) {

        try {
            // Test to see if the last name is valid. An exception will be thrown if invalid.
            isValidName(lastTextField.getText());

            // If no error, proceed

            // Create a predicate based on the text in the Last Name text field
            Predicate<Person> filterPredicate = person -> person.getLastName().toLowerCase().contains(lastTextField.getText().toLowerCase());

            // Create a filtered version of the address list based on the predicate
            FilteredList<Person> filteredAddressList = new FilteredList<>(addressList);
            filteredAddressList.setPredicate(filterPredicate);

            // Adjust the table to reflect the filtered list
            addressBookTable.setItems(filteredAddressList);
        }
        catch (IllegalArgumentException e) {
            // Display warning message
            System.out.println(e.getMessage());
            showWarning(e.getMessage());
        }

    }

    // Validate name
    private void isValidName(String name) {
        if (!name.matches("^[a-zA-Z]*$")) {
            throw new IllegalArgumentException("Invalid name. First and last name must contain only letters.");
        }
    }

    // Validate state
    private void isValidState(String state) {
        if (!(state.matches("^[a-zA-Z]*$") && state.length() == 2)) {
            throw new IllegalArgumentException("Invalid state abbreviation. State must be a two-letter alpha abbreviation.");
        }
    }

    // Validate zip code
    private void isValidZip(String zip) {
        if (!zip.matches("^\\d{5}(-\\d{4})?$")) {
            throw new IllegalArgumentException("Invalid zip code. Zip must be a 5 digit number or 5 digits - 4 digits (i.e., 12345 or 12345-1234)");
        }
    }

    // Dialog Box for invalid data entry
    @FXML
    private void showWarning (String message) {
        Alert warning = new Alert(Alert.AlertType.WARNING);
        warning.setTitle("Invalid Input");
        warning.setContentText(message);
        warning.setHeaderText("Invalid Input");
        warning.showAndWait();
    }

    private void saveToCSV() {
        try(FileWriter writer = new FileWriter(csvFile)) {
            // Make the column titles
            writer.write("First Name,Last Name,Address,City,State,Zip\n");

            // Write each record
            for (Person person : addressList) {
                writer.write(String.format("%s,%s,%s,%s,%s,%s\n",
                        person.getFirstName(), person.getLastName(),
                        person.getAddress(), person.getCity(),
                        person.getState(), person.getZip()));
            }
        }
        catch (IOException e) {
            System.out.println("Error in saving to CSV");
        }
    }
    private void loadFromCSV() {
        try (Scanner scanner = new Scanner(csvFile)) {
            // Skip the header line
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }

            // Read each line and add it to the addressList
            while (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                if (data.length == 6) {
                    addressList.add(new Person(data[0], data[1], data[2], data[3], data[4], data[5]));
                }
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("CSV file not found during loading.");
        }
    }
}