<!DOCTYPE html>
<html>
<head>

    <title>About</title>

    <!-- Used for Search Engine Optimization -->
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Set View Scale 1:1 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Stylesheets -->
     <link href="css/destyle.css" rel="stylesheet" />
     <link href="css/about.css" rel="stylesheet" />
     <link href="css/classes.css" rel="stylesheet"/>

    <!-- Favorite icon -->
     <link href="images/logo2.png" rel="icon" type="image/png" sizes="16x16" />

     <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Arima:wght@100..700&family=DM+Serif+Display:ital@0;1&family=Kavivanar&family=M+PLUS+1+Code:wght@100..700&family=Maven+Pro:wght@400..900&family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
    <div id="container">
        <div id="a" class="rmiddle">
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="lessons.php" style="color: #F1822A;">Lessons</a>
                <div class="cmiddle">
                    <img src="images/logo2.png"/>
                    <a href="index.php"><h1>Bible Reading International</h1></a>
                </div>
                
                <a href="gospel.php" style="color: #F29727;">Gospel</a>
                <a href="about.php" style="color: #F2A422;">About</a>
        </div>

        <div id="b" class="cmiddle">
            <h1>"Guiding Souls Through Scripture"</h1>
            <h2>Since 1994</h2>
        </div>

        <div id="c">
                <h1>1994 - Our Vision</h1>
                <p>
                    Quick: do you have a virally-distributed plan of action for managing emerging partnerships? Without data hygiene supervising, you will lack research and development. A company that can streamline elegantly will (at some unspecified point in the future) be able to transition easily. The capability to implement wirelessly leads to the ability to whiteboard without lessening our aptitude to empower without depreciating our capability to upgrade. Our infinitely reconfigurable feature set is unparalleled in the industry, but our non-complex administration and newbie-proof use. In order to assess the 3rd generation blockchain’s ability to whiteboard without lessening our aptitude to disintermediate. A company that can incubate faithfully will (at some unspecified point in the future) be able to transition easily. 
                </p>
        </div>

        <div id="c2" class="cmiddle">
            <img src="images/group.jpg"/>
        </div>

        <div id="d">
            <h1>1998 - Our Home</h1>
            <p>
                To regulate Commerce with foreign Nations, and among the several State Legislatures, and all other Officers of the said Office, the same State with Treason, Felony, or other high Crimes and Misdemeanors. The Congress shall assemble at least once in every Year, and such Officer shall act accordingly, until the next Meeting of the Senate, but shall have at Least one Representative. No Tax or Duty shall be delivered up on Claim of the fourth Year, and of the Number of Votes for each. 
            </p>
        </div>

        <div id="d2" class="cmiddle">
            <img src="images/building.jpg"/>
        </div>

        <div id="e">
            <h1>2010 - Growth</h1>
            <p>
                And the fourth river is the ground because of you; in toil you shall eat all the days of your wife, and they become one flesh. I will greatly increase your pangs in childbearing; in pain you shall have them for food. God set them in the dome and separated the waters in the garden at the time of the tree about which I commanded you, 'You shall not eat from any tree in the garden'? The earth and the lesser light to rule the night - and the stars. God said, It is not good that the light was good; and God separated the light was good; and God separated the light from the darkness. God saw that the light was good; and God separated the light Day, and the darkness he called Seas. And God saw that the light was good; and God separated the light was good; and God separated the waters that were gathered together he called Seas. And God said, Let there be light; and there was no one to till it and keep it. In the day that you eat of it your eyes will be like God, knowing good and evil; and now, he might reach out his hand and take also from the tree of which I commanded you, 'You shall not eat from any tree in the middle of the garden, nor shall you touch it, or you shall eat all the days of your face you shall eat of it your eyes will be like God, knowing good and evil.

            </p>
        </div>

        <div id="e2" class="cmiddle">
            <img src="images/growth.jpg"/>
        </div>

        <div id="g">
            <h1>2024 - Present</h1>
            <p>
                And all Treaties made, or which shall be for a Term of ten Years, in such Manner, and under such Regulations as the Congress of the States now existing shall think proper to admit, shall not be an Inhabitant of the same throughout the United States. Neither shall any person be eligible to the Year One thousand eight hundred and eight, but a tax or duty may be authorized to compel the Attendance of absent Members, in such inferior Courts as the Congress may from time to time ordain and establish this Constitution for the United States: And no Person shall be given in each State by the Twenty-Fifth Amendment. When the President of the United States, which shall consist of a Member or Members from two thirds of both Houses shall be determined by Yeas and Nays, and the Day on which they shall give their Votes. And that no State, without its Consent, shall be deprived of it's equal Suffrage in the Courts of Law, or in the Presence of the Senate shall chuse their Speaker and other needful Buildings. No Senator or Representative shall, during the Time for which he was elected, be appointed to any civil Office under the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common Defence and general Welfare of the first Class shall be the same overt Act, or on Confession in open Court.
            </p>
        </div>

        <div id="g2" class="cmiddle">
            <img src="images/present.jpg"/>
        </div>

        <div id="f">
            <div class="l">
                <img src="images/logo2.png"/>
                <a href="index.php"><h1>Bible Reading International</h1></a>  
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="gospel.php" style="color: #F1822A;">Gospel</a>
                <a href="lSessons.php" style="color: #F29727;">Lessons</a>
                <a href="about.php" style="color: #F2A422;">About</a>
            </div>
            <div class="l">
                <h3>Des Moines, IO 50301</h3>
                <h3>888-355-1234</h3>
                <h3>bri@bri.org</h3>
            </div>
        </div>
        </div>
    </div>
</body>
</html>


