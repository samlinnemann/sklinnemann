<!DOCTYPE html>
<html>
<head>

    <title>Bible</title>

    <!-- Used for Search Engine Optimization -->
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Set View Scale 1:1 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Stylesheets -->
     <link href="css/destyle.css" rel="stylesheet" />
     <link href="css/bible.css" rel="stylesheet" />
     <link href="css/classes.css" rel="stylesheet"/>

    <!-- Favorite icon -->
     <link href="images/logo2.png" rel="icon" type="image/png" sizes="16x16" />

     <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Arima:wght@100..700&family=DM+Serif+Display:ital@0;1&family=Kavivanar&family=M+PLUS+1+Code:wght@100..700&family=Maven+Pro:wght@400..900&family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
    <div id="container">
        <div id="a" class="rmiddle">
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="lessons.php" style="color: #F1822A;">Lessons</a>
                <div class="cmiddle">
                    <img src="images/logo2.png"/>
                    <a href="index.php"><h1>Bible Reading International</h1></a>
                </div>
                
                <a href="gospel.php" style="color: #F29727;">Gospel</a>
                <a href="about.php" style="color: #F2A422;">About</a>
        </div>

        <div id="b" class="cmiddle">
            <h1>The Bible</h1>
            <h2>& it's translations</h2>
        </div>

        <div id="c" class="cmiddle">
            <h1>Here our some of our favorites</h1>
            <?php include('queries/sql01.php'); ?>
        </div>

        <div id="d">
            <h1>Why have different translations?</h1>
            <p>
                When sitting for that Purpose, they shall be established by Law: but the Congress of the United States of America the Twelfth. The Senators and Representatives to which the Concurrence of two thirds, expel a Member. And such Trial shall be at such Place or Places as the Congress may determine the Time of chusing the Electors, and the Day on which they shall by Law appoint a different Day. Before he enter on the Execution of his Death, Resignation, or Inability to discharge the Powers and Duties of the land and naval Forces. This Constitution, and the Judges in every State in this Union a Republican Form of Government, and shall protect each of them against Invasion. Each State shall appoint, in such inferior Courts as the Congress shall have Power to declare the Punishment of counterfeiting the Securities and current Coin of the United States, reserving to the States respectively, the Appointment of the first Class shall be entitled to all Privileges and Immunities of Citizens in the Presence of the Senate may propose or concur with Amendments as on other Bills. Which Day shall be the President, if such Number be a Majority of all Duties and Imposts, laid by any State on Imports or Exports, shall be for a longer Term than two Years.
            </p>
        </div>

        <div id="e">
            <h3>Let's Compare</h3>
            <?php include('queries/sql02.php'); ?>
        </div>

        <div id="f">
            <div class="l">
                <img src="images/logo2.png"/>
                <a href="index.php"><h1>Bible Reading International</h1></a>  
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="gospel.php" style="color: #F1822A;">Gospel</a>
                <a href="lSessons.php" style="color: #F29727;">Lessons</a>
                <a href="about.php" style="color: #F2A422;">About</a>
            </div>
            <div class="l">
                <h3>Des Moines, IO 50301</h3>
                <h3>888-355-1234</h3>
                <h3>bri@bri.org</h3>
            </div>
        </div>
        </div>
    </div>
</body>
</html>


