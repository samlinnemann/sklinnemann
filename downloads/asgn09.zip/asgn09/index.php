<!DOCTYPE html>
<html>
<head>

    <title>Home</title>

    <!-- Used for Search Engine Optimization -->
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Set View Scale 1:1 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Stylesheets -->
     <link href="css/destyle.css" rel="stylesheet" />
     <link href="css/style.css" rel="stylesheet" />
     <link href="css/classes.css" rel="stylesheet"/>

    <!-- Favorite icon -->
     <link href="images/logo2.png" rel="icon" type="image/png" sizes="16x16" />

     <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Arima:wght@100..700&family=DM+Serif+Display:ital@0;1&family=Kavivanar&family=M+PLUS+1+Code:wght@100..700&family=Maven+Pro:wght@400..900&family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
    <div id="container">
        <div id="a" class="rmiddle">
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="lessons.php" style="color: #F1822A;">Lessons</a>
                <div class="cmiddle">
                    <img src="images/logo2.png"/>
                    <a href="index.php"><h1>Bible Reading International</h1></a>
                </div>
                
                <a href="gospel.php" style="color: #F29727;">Gospel</a>
                <a href="about.php" style="color: #F2A422;">About</a>
        </div>

        <div id="b" class="cmiddle">
        <h1>
                    "For the word of God is living and active, and sharper than any two-edged sword, even penetrating as far as the division
                    of soul and spirit, of both joints and marrow, 
                    and able to judjge the thoughts and  
                    intentions of the heart."
                </h1>
                <h2>-Hebrews 4:12</h2>
        </div>

        <div id="c">
        <h1>"Guiding Souls Through Scripture"</h1>
            <p>
                And God said, Let the waters in the earth and the heavens. So out of the air, and brought them to the tree of which I commanded you, 'You shall not eat from any tree in the garden'? God blessed them, and God said to the sight and good for food, and that it was good. By the sweat of your face you shall eat the plants of the field. But of the tree that is pleasant to the sight and good for food, the tree of life. By the sweat of your face you shall eat all the days of your wife, and clothed them. But God said, 'You shall not eat from any tree in the garden at the time of the LORD God took the man and put him in the midst of the garden, and the waters that were gathered together he called Seas. And God saw that the tree was good for food, the tree of life, I have given every green plant for food. God set them in the dome Sky. And there was morning, the fifth day. He drove out the man; and at the time of the evening breeze, and the man and put him in the garden of Eden, to till it and keep it.

            </p>
        </div>

        <div id="d" class="left">
            <div>
                <h1>The</h1>
                <h1>bible</h1>
            </div>
            <div>
                <p>Did you know there are over 900 english versions of the Bible?</p>
                <p>What's the difference in Bible versions?</p>
                <a href="bible.php">CLick here to find out</a>
            </div>
        </div>

        <div id="e" class="right">
            <div>
                <p>Our lessons go over one chapter of the Bible</p>
                <p>Apply the bible in your daily life!</p>
                <a href="lessons.php">Click here to read</a>
            </div>
            <div>
                <h1>Our</h1>
                <h1>Lessons</h1>
            </div>
        </div>
        
        <div id="g" class="left">
            <div>
                <h1>The</h1>
                <h1>Gospel</h1>
            </div>
            <div>
                <p>Our redemption through the sacrifice and ressurection of Jesus</p>
                <p>Do you want to know God?</p>
                <a href="lessons.php">Click here to learn more</a>
            </div>
        </div>
        
        <div id="h" class="right">
            <div>
                <p>Our history and beginnings</p>
                <p>Why we do what we do</p>
                <a href="about.php">Click here to learn about us</a>
            </div>
            <div>
                <h1>About</h1>
                <h1>Us</h1>
            </div>
        </div>

        <div id="f">
            <div class="l">
                <img src="images/logo2.png"/>
                <a href="index.php"><h1>Bible Reading International</h1></a>  
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="gospel.php" style="color: #F1822A;">Gospel</a>
                <a href="lSessons.php" style="color: #F29727;">Lessons</a>
                <a href="about.php" style="color: #F2A422;">About</a>
            </div>
            <div class="l">
                <h3>Des Moines, IO 50301</h3>
                <h3>888-355-1234</h3>
                <h3>bri@bri.org</h3>
            </div>
        </div>
        </div>
    </div>
</body>
</html>


