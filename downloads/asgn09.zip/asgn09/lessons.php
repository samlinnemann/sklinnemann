<!DOCTYPE html>
<html>
<head>

    <title>Lessons</title>

    <!-- Used for Search Engine Optimization -->
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Set View Scale 1:1 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Stylesheets -->
     <link href="css/destyle.css" rel="stylesheet" />
     <link href="css/lessons.css" rel="stylesheet" />
     <link href="css/classes.css" rel="stylesheet"/>

    <!-- Favorite icon -->
     <link href="images/logo2.png" rel="icon" type="image/png" sizes="16x16" />

     <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Arima:wght@100..700&family=DM+Serif+Display:ital@0;1&family=Kavivanar&family=M+PLUS+1+Code:wght@100..700&family=Maven+Pro:wght@400..900&family=Montserrat+Alternates:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
    <div id="container">
        <div id="a" class="rmiddle">
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="lessons.php" style="color: #F1822A;">Lessons</a>
                <div class="cmiddle">
                    <img src="images/logo2.png"/>
                    <a href="index.php"><h1>Bible Reading International</h1></a>
                </div>
                
                <a href="gospel.php" style="color: #F29727;">Gospel</a>
                <a href="about.php" style="color: #F2A422;">About</a>
        </div>

        <div id="b" class="cmiddle">
            <h1>Our Lessons</h1>
            <h2>Updated Weekly</h2>
        </div>

        <div id="c">
            <h1>This Week's Chapter</h1>
            <h1>Genesis 8 KJV</h1>
            <?php include('queries/sql03.php'); ?>
        </div>

        <div id="d" class="cmiddle">
            <h1>This Week's Lesson</h1>
            <a href="https://www.blueletterbible.org/comm/guzik_david/study-guide/genesis/genesis-8.cfm" target="_blank">Study Guide for Genesis 8 by David Guzik</a>
        </div>

        <div id="e" class="cmiddle">
            <h1>How do we write and choose our lessons?</h1>
            <p>
                The woman whom you gave to be with me, she gave me fruit from the tree, and I was afraid, because I was naked; and I hid myself. So the LORD God planted a garden in Eden, in the east; and there was no one to till the ground from which he was taken. And let them be lights in the dome from the darkness. And God saw that it was a delight to the eyes, and that the tree was good for food, the tree of life. So the LORD God formed every animal of the field was yet in the east; and there he put the man whom he had made, and indeed, it was very good. And there was morning, the second day. He said, I heard the sound of the LORD God made garments of skins for the man and for his wife, and clothed them. They heard the sound of you in the garden of Eden he placed the cherubim, and a sword flaming and turning to guard the way to the tree of life also in the midst of the field was yet in the earth across the dome of the sky. To the woman he said, I heard the sound of the LORD God sent him forth from the darkness. And God saw everything that has the breath of life, I have given you every plant yielding seed that is upon the face of the heavens and the earth across the dome of the sky.
            </p>
            <img src="images/lessons.jpg"/>
        </div>

        <div id="f">
            <div class="l">
                <img src="images/logo2.png"/>
                <a href="index.php"><h1>Bible Reading International</h1></a>  
                <a href="bible.php" style="color: #F25430;">Bible</a>
                <a href="gospel.php" style="color: #F1822A;">Gospel</a>
                <a href="lSessons.php" style="color: #F29727;">Lessons</a>
                <a href="about.php" style="color: #F2A422;">About</a>
            </div>
            <div class="l">
                <h3>Des Moines, IO 50301</h3>
                <h3>888-355-1234</h3>
                <h3>bri@bri.org</h3>
            </div>
        </div>
        </div>
    </div>
</body>
</html>


