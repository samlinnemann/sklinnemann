<?php
// Connect to server and database
$con = mysqli_connect("localhost", "jwestfal_student", "student#2024", "jwestfal_bible");

// Error check for failed connection to server
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Perform Query
$sql = "SELECT
    t_kjv.t AS kjv_text
FROM
    t_kjv
WHERE
    t_kjv.b = 8";

if ($result = mysqli_query($con, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div>";
            echo "<p>" . htmlspecialchars($row['kjv_text']) . "</p>";
            echo "</div>";
        }

        // Free Result Set (Free up memory)
        mysqli_free_result($result);
    } else {
        echo "No Records Matching your Query were Found.";
    }
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($con);
}

// Close Connection
mysqli_close($con);
?>
