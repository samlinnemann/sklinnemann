<?php
// Connect to server and database
$con = mysqli_connect("localhost", "jwestfal_student", "student#2024", "jwestfal_bible");

// Error check for failed connection to server
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Perform Query
$sql = "SELECT abbreviation, version, info_url FROM bible_version_key";

if ($result = mysqli_query($con, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<tr>"; //Table row (HTML)
        //Creating table headings
        echo "<th>Abbreviation</th>";
        echo "<th>Version</th>";
        echo "<th>More Info</th>";
        echo "</tr>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['abbreviation']) . "</td>";
            echo "<td>" . htmlspecialchars($row['version']) . "</td>";
            echo "<td><a href='" . htmlspecialchars($row['info_url']) . "'>Link</a></td>";
            echo "</tr>";
        }
        echo "</table>";

        // Free Result Set (Free up memory)
        mysqli_free_result($result);
    } else {
        echo "No Records Matching your Query were Found.";
    }
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($con);
}

// Close Connection
mysqli_close($con);
?>

