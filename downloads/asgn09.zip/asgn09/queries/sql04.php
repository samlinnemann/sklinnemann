<?php
// Connect to server and database
$con = mysqli_connect("localhost", "jwestfal_student", "student#2024", "jwestfal_bible");

// Error check for failed connection to server
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Perform Query
$sql = "SELECT
    t_kjv.t AS kjv_text,
    key_english.n AS book,
    t_kjv.c AS chapter,
    t_kjv.v AS verse
FROM
    t_kjv
JOIN
    key_english ON t_kjv.b = key_english.b
WHERE
    (t_kjv.b = 41 AND t_kjv.c = 10 AND t_kjv.v = 45) OR  
    (t_kjv.b = 45 AND t_kjv.c = 5 AND t_kjv.v = 8) OR
    (t_kjv.b = 45 AND t_kjv.c = 6 AND t_kjv.v = 23) OR
    (t_kjv.b = 45 AND t_kjv.c = 8 AND t_kjv.v = 1) OR    
    (t_kjv.b = 45 AND t_kjv.c = 8 AND t_kjv.v = 32) OR  
    (t_kjv.b = 47 AND t_kjv.c = 5 AND t_kjv.v = 21) OR    
    (t_kjv.b = 47 AND t_kjv.c = 8 AND t_kjv.v = 9) OR  
    (t_kjv.b = 54 AND t_kjv.c = 1 AND t_kjv.v = 15) OR   
    (t_kjv.b = 62 AND t_kjv.c = 4 AND t_kjv.v = 10) OR    
    (t_kjv.b = 66 AND t_kjv.c = 5 AND t_kjv.v = 9)";

if ($result = mysqli_query($con, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div>";
            echo "<h2>" . htmlspecialchars($row['book']) . " " . htmlspecialchars($row['chapter']) . ":" . htmlspecialchars($row['verse']) . "</h2>";
            echo "<p>" . "'" . htmlspecialchars($row['kjv_text']) . "'" . "</p>";
            echo "</div>";
        }

        // Free Result Set (Free up memory)
        mysqli_free_result($result);
    } else {
        echo "No Records Matching your Query were Found.";
    }
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($con);
}

// Close Connection
mysqli_close($con);
?>
