<?php
// Connect to server and database
$con = mysqli_connect("localhost", "jwestfal_student", "student#2024", "jwestfal_bible");

// Error check for failed connection to server
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Perform Query
$sql = "SELECT
    t_kjv.t AS kjv_text,
    t_ylt.t AS ylt_text,
    t_asv.t AS asv_text,
    t_bbe.t AS bbe_text,
    t_web.t AS web_text,
    t_kjv.b, t_kjv.c, t_kjv.v
FROM
    t_kjv
JOIN
    t_ylt ON t_kjv.b = t_ylt.b AND t_kjv.c = t_ylt.c AND t_kjv.v = t_ylt.v
JOIN
    t_asv ON t_kjv.b = t_asv.b AND t_kjv.c = t_asv.c AND t_kjv.v = t_asv.v
JOIN
    t_bbe ON t_kjv.b = t_bbe.b AND t_kjv.c = t_bbe.c AND t_kjv.v = t_bbe.v
JOIN
    t_web ON t_kjv.b = t_web.b AND t_kjv.c = t_web.c AND t_kjv.v = t_web.v
WHERE
    (t_kjv.b, t_kjv.c, t_kjv.v) IN ((1, 1, 9), (1, 3, 10))
";

if ($result = mysqli_query($con, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div>";
            echo "<h1>" . "Genesis" . " " . htmlspecialchars($row['c']) . ":" . htmlspecialchars($row['v']) . "</h1>";
            echo "<h2>KJV: " . htmlspecialchars($row['kjv_text']) . "</h2>";
            echo "<h2>YLT: " . htmlspecialchars($row['ylt_text']) . "</h2>";
            echo "<h2>ASV: " . htmlspecialchars($row['asv_text']) . "</h2>";
            echo "<h2>BBE: " . htmlspecialchars($row['bbe_text']) . "</h2>";
            echo "<h2>WEB: " . htmlspecialchars($row['web_text']) . "</h2>";
            echo "</div>";
        }

        // Free Result Set (Free up memory)
        mysqli_free_result($result);
    } else {
        echo "No Records Matching your Query were Found.";
    }
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($con);
}

// Close Connection
mysqli_close($con);
?>
