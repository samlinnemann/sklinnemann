package snake;

import java.awt.*;
import java.awt.event.*;
import java.util.Random;

import javax.swing.*;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements ActionListener {

  /* Core application configuration */
  static final int SCREEN_WIDTH = 800;
  static final int SCREEN_HEIGHT = 800;
  static final int UNIT_SIZE = 25;
  static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / UNIT_SIZE;
  static final int DELAY = 75;

  /* Storage of snake body cordinates */
  final int x[] = new int[GAME_UNITS];
  final int y[] = new int[GAME_UNITS];
  int bodyParts = 6;

  /* Position of apples on the screen and number of apples eaten */
  int appleEaten;
  int appleX;
  int appleY;
  
  // Color variable
  int color = 0;
  
  // mode variable
  int mode = 0;

  /* Snake Movement definition */
  char direction = 'R';
  boolean running = false;

  /* Game timer configuration */
  Timer timer;
  Random random;

  GamePanel() {
    random = new Random();
    this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
    this.setBackground(Color.black);
    this.setFocusable(true);
    this.addKeyListener(new MyKeyAdapter());
    
    startGame();
  }

  public void startGame() {
    newApple();
    running = true;
    timer = new Timer(DELAY, this);
    timer.start();
  }
  
  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    
    draw(g);
  }

  public void draw(Graphics g) {

    if (running) {

      // Definition of visible game lines
      for (int i = 0; i < SCREEN_HEIGHT / UNIT_SIZE; i++) {
        g.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
        g.drawLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
      }

      // Apple Color
      g.setColor(Color.red);
      g.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);

      for (int i = 0; i < bodyParts; i++) {
        if (i == 0) {
          // Snake Head
          //added switch statement for head color
          switch(color) {
              case 1:
                g.setColor(Color.blue);
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              case 2:
                g.setColor(Color.yellow);
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);    
                break;
              case 3:
                g.setColor(Color.magenta);
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              case 4:
                g.setColor(Color.white);
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              default:
                g.setColor(Color.green);
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
          }
        } else {
          // Snake Body
          //added switch statemet for body color
          switch(color) {
              case 1:
                g.setColor(new Color(65,105,225));
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              case 2:
                g.setColor(new Color(204,204,0));
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              case 3:
                g.setColor(new Color(138,43,226));
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              case 4:
                // Calculate hue value based on current time
                float hue = (System.currentTimeMillis() % 10000) / 10000f; // Varies between 0 and 1 over time
    
                // Set color based on hue
                Color rainbowColor = Color.getHSBColor(hue, 1.0f, 1.0f);
    
                g.setColor(rainbowColor);
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
              default:
                g.setColor(new Color(45, 180, 0));
                g.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                break;
          }
        }
      }

      g.setColor(Color.white);
      g.setFont(new Font("Fira Code", Font.BOLD, 40));
      FontMetrics metrics = getFontMetrics(g.getFont());
      g.drawString("Score: " + appleEaten, (SCREEN_WIDTH - metrics.stringWidth("Score: " + appleEaten)) / 2,
          g.getFont().getSize());

    } else {
      gameOver(g);
    }

  }
  
  
  public void newApple() {
    appleX = random.nextInt((int) (SCREEN_WIDTH / UNIT_SIZE)) * UNIT_SIZE;
    appleY = random.nextInt((int) (SCREEN_HEIGHT / UNIT_SIZE)) * UNIT_SIZE;
  }

  public void move() {
    for (int i = bodyParts; i > 0; i--) {
      x[i] = x[i - 1];
      y[i] = y[i - 1];
    }

    switch (direction) {
      case 'U':
        y[0] = y[0] - UNIT_SIZE; // y[0] = Snake Head
        break;

      case 'D':
        y[0] = y[0] + UNIT_SIZE;
        break;

      case 'L':
        x[0] = x[0] - UNIT_SIZE;
        break;
      case 'R':
        x[0] = x[0] + UNIT_SIZE;
    }
  }

  public void checkApple() {
    if ((x[0] == appleX) && (y[0] == appleY)) {
      bodyParts++;
      appleEaten++;
      newApple();
    }
  }

  public void checkCollisions() {
    // Check if the head collided with the body
    for (int i = bodyParts; i > 0; i--) {
      if ((x[0] == x[i]) && (y[0] == y[i])) {
        running = false;

      }
    }
    switch(mode) {
        case 1:
            //collision with left sends to right
            if (x[0] < 0) {
                x[0] = SCREEN_WIDTH;
            }
            //collision with right border sends left
            if (x[0] > SCREEN_WIDTH) {
                x[0] = 0;
            }
            //Collision with top border sends bottom
            if (y[0] < 0) {
                y[0] = SCREEN_HEIGHT;
            }
            //Collision with bottom border sends top
            if (y[0] > SCREEN_HEIGHT) {
                y[0] = 0;
            }
            break;
        default:
            // Check if the head collided with the left border
            if (x[0] < 0) {
                running = false;
            }
            // Check if the head collided with the right border
            if (x[0] > SCREEN_WIDTH) {
                running = false;
            }
            // Check if the head collided with the top border
            if (y[0] < 0) {
                running = false;
            }
            // Check if the head collided with the bottom border
            if (y[0] > SCREEN_HEIGHT) {
                running = false;
            }
            break;
    }

    if (!running) {
      timer.stop();
    }
  }

  public void gameOver(Graphics g) {
    // Score
    g.setColor(Color.white);
    g.setFont(new Font("Fira Code", Font.BOLD, 40));
    FontMetrics metrics1 = getFontMetrics(g.getFont());
    g.drawString("Final Score: " + appleEaten, (SCREEN_WIDTH - metrics1.stringWidth("Final Score: " + appleEaten)) / 2,
        g.getFont().getSize());
    // Game Over text
    g.setColor(Color.red);
    g.setFont(new Font("Fira Code", Font.BOLD, 75));
    FontMetrics metrics2 = getFontMetrics(g.getFont());
    g.drawString("GameOver", (SCREEN_WIDTH - metrics2.stringWidth("GameOver")) / 2, SCREEN_HEIGHT / 2);
    
    // Prompt for gameRestart
    g.setColor(Color.white);
    g.setFont(new Font("Fira Code", Font.BOLD, 30));
    FontMetrics metrics3 = getFontMetrics(g.getFont());
    g.drawString("Press Space to Restart", (SCREEN_WIDTH - metrics3.stringWidth("Press Space to Restart")) / 2, SCREEN_HEIGHT / 2 + 50);
    
    // Prompt for Color
    g.setColor(Color.white);
    g.setFont(new Font("Fira Code", Font.BOLD, 30));
    FontMetrics metrics4 = getFontMetrics(g.getFont());
    g.drawString("Select Color - Spacebar = Default", (SCREEN_WIDTH - metrics4.stringWidth("Select Color - Spacebar = Default")) / 2, SCREEN_HEIGHT / 2 + 100);
    
    // Color menu text
    g.setColor(Color.white);
    g.setFont(new Font("Fira Code", Font.BOLD, 30));
    FontMetrics metrics5 = getFontMetrics(g.getFont());
    g.drawString("1=Blue - 2=Yellow - 3=Magenta", (SCREEN_WIDTH - metrics5.stringWidth("1=Blue - 2=Yellow - 3=Magenta")) / 2, SCREEN_HEIGHT / 2 + 150);
    
    // Game Mode Menu
    g.setColor(Color.white);
    g.setFont(new Font("Fira Code", Font.BOLD, 30));
    FontMetrics metrics6 = getFontMetrics(g.getFont());
    g.drawString("Press A For Arcade Mode", (SCREEN_WIDTH - metrics6.stringWidth("Press A For Arcade Mode")) / 2, SCREEN_HEIGHT / 2 + 200);
  }

  //function for restarting game
  public void gameRestart() {
    //resetting the to default game parameters
    appleEaten = 0;
    bodyParts = 6;
    direction = 'R';
    running = false;
    for (int i = 0; i < bodyParts; i++) {
        x[i] = 0;
        y[i] = 0;
    }
    //starting the game again
    startGame();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if (running) {
      move();
      checkApple();
      checkCollisions();
    }

    repaint();
  }

  public class MyKeyAdapter extends KeyAdapter {
    @Override
    public void keyPressed(KeyEvent e) {
      switch (e.getKeyCode()) {
        case KeyEvent.VK_LEFT:
          if (direction != 'R') {
            direction = 'L';
          }
          break;
        case KeyEvent.VK_RIGHT:
          if (direction != 'L') {
            direction = 'R';
          }
          break;
        case KeyEvent.VK_UP:
          if (direction != 'D') {
            direction = 'U';
          }
          break;
        case KeyEvent.VK_DOWN:
          if (direction != 'U') {
            direction = 'D';
          }
          break;
        //Additon of spacebar key for restarting game
        case KeyEvent.VK_SPACE:
            if (running == false) {
                gameRestart();
                color = 0;
                mode = 0;
            }
            break;
        //Addition of Number keys for selecting new color
        case KeyEvent.VK_1:
            if (running == false) {
                gameRestart();
                color = 1;
                mode = 0;
            }
            break;
        case KeyEvent.VK_2:
            if (running == false) {
                gameRestart();               
                color = 2;
                mode = 0;
            }
            break;
        case KeyEvent.VK_3:
            if (running == false) {
                gameRestart();               
                color = 3;
                mode = 0;
            }
            break;
        case KeyEvent.VK_A:
            if (running == false) {
                mode = 1;
                color = 4;
                gameRestart();
            }
        default:
            break;
      }
    }
  }
}
